/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aritmetica;

import gui.AbstractFactory;
import Convertidor.Convertidor;
import Convertidor.TypeC;

/**
 *
 * @author estudiante
 */
public class AritmeticaFact implements AbstractFactory{
    @Override
    public Operar getOperar(Type type){
        switch (type){
            case Suma:
                return new Suma();
            case Resta:
                return new Resta();
            case Mult:
                return new Multiplicacion();
            case Div:
                return new Division();
        }
        return null;
    }
    
   @Override
   public Convertidor getConvertidor(TypeC type){
       return null;
   }
}
