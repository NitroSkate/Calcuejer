/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Aritmetica.Operar;
import Aritmetica.Type;
import Convertidor.Convertidor;
import Convertidor.TypeC;

/**
 *
 * @author estudiante
 */
public interface AbstractFactory {
    Operar getOperar(Type type);
    Convertidor getConvertidor(TypeC type);
    
}
