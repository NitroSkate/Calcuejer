/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;


import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author estudiante
 */
public class Ventana extends JPanel{
    
    private int WIDTH=300, HEIGHT=300;
    private int widthTF=120, heightTF=80;
    private int widthBT=60, heightBT=30;
    JButton boton;
    JTextField textfield1, textfield2;
    
    public Ventana(){
        boton=new JButton("Copiar");
        textfield1=new JTextField();
        textfield2=new JTextField();
        textfield2.setBounds(100, 200, widthTF, heightTF);
        textfield1.setBounds(100, 40, widthTF, heightTF);
        boton.setBounds(120,115,widthBT,heightBT);
        boton.addActionListener ( new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                textfield2.setText(textfield1.getText());
                
            }
        });
        textfield1.setEditable(true);
        textfield2.setEditable(false);
        add(boton);
        add(textfield1);
        add(textfield2);
        setLayout(null);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));        
    }    
}
