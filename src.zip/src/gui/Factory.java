/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import Aritmetica.AritmeticaFact;
import Convertidor.ConvertidorFact;

/**
 *
 * @author NitroSkate <00159817@uca.edu.sv>
 */
public class Factory {
    public static AbstractFactory getFactory(String type){
        switch(type){
            case "Operar":
                return new AritmeticaFact();
            case "Convertir":
                return new ConvertidorFact();
        }
        return null;
    }
}
