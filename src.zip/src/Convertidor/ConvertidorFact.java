/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Convertidor;

import gui.AbstractFactory;
import Aritmetica.Operar;
import Aritmetica.Type;

/**
 *
 * @author NitroSkate <00159817@uca.edu.sv>
 */
public class ConvertidorFact implements AbstractFactory {
    
    @Override 
    public Convertidor getConvertidor(TypeC type){
        return new Binario();
    }
    
    @Override
    public Operar getOperar(Type type){
        return null;
    }

}
