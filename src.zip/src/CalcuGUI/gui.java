/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CalcuGUI;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author estudiante
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author estudiante
 */
public class gui extends JPanel{
    
    private int WIDTH=250, HEIGHT=300;
    private int widthTF=120, heightTF=40;
    private int widthBT=60, heightBT=30;
    JButton boton;
    JButton boton1;
    JButton boton2;
    JButton boton3;
    JTextField textfield1, textfield2;
    
    public gui(){
        boton=new JButton("+");
        boton1=new JButton("-");
        boton2=new JButton("-");
        boton3=new JButton("/");
        textfield1=new JTextField();
        textfield2=new JTextField();
        textfield2.setBounds(60, 200, widthTF, heightTF);
        textfield1.setBounds(60, 40, widthTF, heightTF);
        boton.setBounds(55,85,widthBT,heightBT);
        boton1.setBounds(125, 85, widthBT, heightBT);
        boton2.setBounds(55, 125, widthBT, heightBT);
        boton3.setBounds(125, 125, widthBT, heightBT);
        boton.addActionListener ( new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                textfield2.setText(textfield1.getText());
                
            }
        });
        textfield1.setEditable(true);
        textfield2.setEditable(false);
        add(boton);
        add(boton1);
        add(boton2);
        add(boton3);
        add(textfield1);
        add(textfield2);
        setLayout(null);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));        
    }    
}